import { z } from 'zod';
import { DEFAULT_LOCALE, SUPPORTED_LOCALES } from './i18n';

const STORAGE_KEY = 'coruja.save.v1';

export const starsSchema = z.number().int().min(0).max(3);

const settingsSchema = z.object({
  locale: z.enum(SUPPORTED_LOCALES),
  soundEnabled: z.boolean(),
  musicEnabled: z.boolean(),
  timedMode: z.boolean(),
  buttonsOnly: z.boolean(),
  highContrast: z.boolean(),
  dyslexiaFont: z.boolean(),
  fontScale: z.number().int().min(0).max(2)
});

export const saveSchema = z.object({
  version: z.literal(1),
  coins: z.number().int().min(0),
  stars: z.record(z.string(), starsSchema),
  settings: settingsSchema
});

export type SaveData = z.infer<typeof saveSchema>;
export type Settings = SaveData['settings'];

export const DEFAULT_SAVE: SaveData = {
  version: 1,
  coins: 0,
  stars: {},
  settings: {
    locale: DEFAULT_LOCALE,
    soundEnabled: true,
    musicEnabled: true,
    timedMode: true,
    buttonsOnly: false,
    highContrast: false,
    dyslexiaFont: false,
    fontScale: 0
  }
};

function storage(): Storage | null {
  try {
    return window.localStorage;
  } catch {
    return null;
  }
}

function readRaw(): unknown {
  const store = storage();
  if (!store) return null;
  const raw = store.getItem(STORAGE_KEY);
  if (!raw) return null;
  try {
    return JSON.parse(raw) as unknown;
  } catch {
    return null;
  }
}

export function load(): SaveData {
  const parsed = saveSchema.safeParse(readRaw());
  if (!parsed.success) return structuredClone(DEFAULT_SAVE);
  return parsed.data;
}

export function write(data: SaveData): SaveData {
  const store = storage();
  if (store) store.setItem(STORAGE_KEY, JSON.stringify(data));
  return data;
}

export function update(change: (draft: SaveData) => void): SaveData {
  const draft = structuredClone(load());
  change(draft);
  return write(draft);
}

export function addCoins(amount: number): SaveData {
  return update((draft) => {
    draft.coins = Math.max(0, draft.coins + amount);
  });
}

export function saveSettings(change: Partial<Settings>): SaveData {
  return update((draft) => {
    draft.settings = { ...draft.settings, ...change };
  });
}

export function recordLevelResult(levelId: string, stars: number): SaveData {
  return update((draft) => {
    const previous = draft.stars[levelId] ?? 0;
    const clamped = Math.min(3, Math.max(1, stars));
    draft.stars[levelId] = Math.max(previous, clamped);
  });
}

export function reset(): SaveData {
  const store = storage();
  if (store) store.removeItem(STORAGE_KEY);
  return structuredClone(DEFAULT_SAVE);
}