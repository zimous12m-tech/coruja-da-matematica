import { loadLevels, loadLevelQuestions, loadWorlds } from '../content/worlds';
import type { Level, World, WorldId } from '../content/schema';
import { addCoins, load, recordLevelResult, saveSettings } from '../services/save';
import { computeStars, featherReward, type Stars } from '../services/progress';
import { configure, play, startMusic } from '../services/audio';
import { setLocale } from '../services/i18n';
import { renderWorldMap } from './screens/worldMap';
import { renderLevelSelect } from './screens/levelSelect';
import { renderGame } from './screens/game';
import { renderComplete } from './screens/complete';
import { renderParentZone } from './screens/parentZone';
import { renderCredits } from './screens/credits';
import { openSettings } from './screens/settingsSheet';

export async function startApp(root: HTMLElement): Promise<void> {
  const worlds = await loadWorlds();

  async function showWorldMap(): Promise<void> {
    const save = load();
    configure(save.settings.soundEnabled, save.settings.musicEnabled);
    renderWorldMap(root, {
      worlds,
      save,
      onOpenWorld: (worldId) => {
        play('click');
        const world = worlds.find((w) => w.id === worldId);
        if (world) void showLevelSelect(world);
      },
      onOpenSettings: () => {
        play('click');
        openSettings({
          current: load().settings,
          onChange: (change) => {
            saveSettings(change);
            const updated = load().settings;
            configure(updated.soundEnabled, updated.musicEnabled);
            if (change.locale) {
              void setLocale(change.locale).then(() => void showWorldMap());
            } else {
              void showWorldMap();
            }
          }
        });
      },
      onOpenParents: () => {
        play('click');
        renderParentZone(root, () => void showWorldMap());
      },
      onOpenCredits: () => {
        play('click');
        renderCredits(root, () => void showWorldMap());
      }
    });
  }

  async function showLevelSelect(world: World): Promise<void> {
    const levels = await loadLevels(world.id as WorldId);
    renderLevelSelect(root, {
      world,
      levels,
      save: load(),
      onOpenLevel: (level) => {
        play('click');
        void playLevel(world, levels, level);
      },
      onBack: () => void showWorldMap()
    });
  }

  async function playLevel(world: World, levels: Level[], level: Level): Promise<void> {
    const questions = await loadLevelQuestions(world.id as WorldId, level.id);
    renderGame(root, {
      questions,
      levelId: level.id,
      boss: level.boss,
      onExit: () => void showLevelSelect(world),
      onFinish: (result) => {
        const stars: Stars = computeStars(result.errors);
        recordLevelResult(level.id, stars);
        const coins = featherReward(result.correct, stars);
        addCoins(coins);
        play('star');

        const currentIndex = levels.findIndex((l) => l.id === level.id);
        const nextLevel = levels[currentIndex + 1];

        renderComplete(root, {
          correct: result.correct,
          total: result.total,
          stars,
          coins,
          hasNextLevel: Boolean(nextLevel),
          onRepeat: () => void playLevel(world, levels, level),
          onNextLevel: () => {
            if (nextLevel) void playLevel(world, levels, nextLevel);
          },
          onBackToMap: () => void showWorldMap()
        });
      }
    });
  }

  await showWorldMap();

  const settings = load().settings;
  if (settings.musicEnabled) startMusic();
}
