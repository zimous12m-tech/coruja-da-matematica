import type { Question } from '../../content/schema';
import { t } from '../../services/i18n';
import { icon } from '../components/icons';
import { renderVisual } from '../components/visual';
import { qs } from '../dom';

export interface GameResult {
  correct: number;
  total: number;
  errors: number;
}

export interface GameDeps {
  questions: readonly Question[];
  levelId: string;
  boss: boolean;
  onExit: () => void;
  onFinish: (result: GameResult) => void;
}

export function renderGame(root: HTMLElement, deps: GameDeps): void {
  const total = deps.questions.length;
  let index = 0;
  let correct = 0;
  let errors = 0;
  let answered = false;

  root.innerHTML = `
    <main class="screen">
      <header class="topbar">
        <button class="btn" type="button" data-exit aria-label="${t('game.exit')}">${icon('exit', 18)}</button>
        <span class="hud__progress" data-progress></span>
        ${deps.boss ? `<span class="chip chip--boss">${icon('crown', 16)}BOSS</span>` : ''}
      </header>
      <div class="card"><p class="question" data-question></p></div>
      <div data-visual></div>
      <div class="options" data-options></div>
      <div class="feedback" data-feedback hidden>
        <p class="feedback__title" data-title></p>
        <span class="feedback__label">${t('game.explanation')}</span>
        <p data-explanation></p>
        <button class="btn btn--primary" type="button" data-next>${icon('next', 18)}<span data-next-label></span></button>
      </div>
    </main>`;

  const progressEl = qs<HTMLSpanElement>(root, '[data-progress]');
  const questionEl = qs<HTMLParagraphElement>(root, '[data-question]');
  const visualEl = qs<HTMLDivElement>(root, '[data-visual]');
  const optionsEl = qs<HTMLDivElement>(root, '[data-options]');
  const feedbackEl = qs<HTMLDivElement>(root, '[data-feedback]');
  const titleEl = qs<HTMLParagraphElement>(root, '[data-title]');
  const explanationEl = qs<HTMLParagraphElement>(root, '[data-explanation]');
  const nextBtn = qs<HTMLButtonElement>(root, '[data-next]');
  const nextLabel = qs<HTMLSpanElement>(root, '[data-next-label]');

  function handlePick(choice: number): void {
    if (answered) return;
    answered = true;
    const q = deps.questions[index];
    if (!q) return;
    const isRight = choice === q.resposta;
    if (isRight) correct += 1;
    else errors += 1;

    optionsEl.querySelectorAll<HTMLButtonElement>('.option').forEach((btn, pos) => {
      btn.disabled = true;
      if (pos === q.resposta) btn.classList.add('is-correct');
      else if (pos === choice) btn.classList.add('is-wrong');
    });

    feedbackEl.hidden = false;
    feedbackEl.className = `feedback ${isRight ? 'is-correct' : 'is-wrong'}`;
    titleEl.textContent = isRight ? t('game.correct') : t('game.wrong');
    explanationEl.textContent = q.explicacao['pt-PT'];
    nextLabel.textContent = index === total - 1 ? t('game.finish') : t('game.next');
    nextBtn.focus();
  }

  function showQuestion(): void {
    const q = deps.questions[index];
    if (!q) return;
    answered = false;
    progressEl.textContent = t('game.progress', { current: index + 1, total });
    questionEl.textContent = q.pergunta['pt-PT'];
    visualEl.innerHTML = renderVisual(q.visual);
    optionsEl.innerHTML = '';
    feedbackEl.hidden = true;

    q.opcoes.forEach((label, pos) => {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'option';
      btn.textContent = label;
      btn.addEventListener('click', () => handlePick(pos));
      optionsEl.appendChild(btn);
    });
  }

  nextBtn.addEventListener('click', () => {
    if (!answered) return;
    if (index === total - 1) {
      deps.onFinish({ correct, total, errors });
      return;
    }
    index += 1;
    showQuestion();
  });

  qs<HTMLButtonElement>(root, '[data-exit]').addEventListener('click', deps.onExit);
  showQuestion();
}
