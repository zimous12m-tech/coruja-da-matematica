import { loadLevels, loadLevelQuestions, loadWorlds } from '../content/worlds';
import type { Level, World, WorldId } from '../content/schema';
import { addCoins, load, recordLevelResult } from '../services/save';
import { computeStars, featherReward, type Stars } from '../services/progress';
import { renderWorldMap } from './screens/worldMap';
import { renderLevelSelect } from './screens/levelSelect';
import { renderGame } from './screens/game';
import { renderComplete } from './screens/complete';

export async function startApp(root: HTMLElement): Promise<void> {
  const worlds = await loadWorlds();

  async function showWorldMap(): Promise<void> {
    renderWorldMap(root, {
      worlds,
      save: load(),
      onOpenWorld: (worldId) => {
        const world = worlds.find((w) => w.id === worldId);
        if (world) void showLevelSelect(world);
      }
    });
  }

  async function showLevelSelect(world: World): Promise<void> {
    const levels = await loadLevels(world.id as WorldId);
    renderLevelSelect(root, {
      world,
      levels,
      save: load(),
      onOpenLevel: (level) => void playLevel(world, levels, level),
      onBack: () => void showWorldMap()
    });
  }

  async function playLevel(world: World, levels: Level[], level: Level): Promise<void> {
    const questions = await loadLevelQuestions(world.id as WorldId, level.id);
    renderGame(root, {
      questions,
      levelId: level.id,
      boss: level.boss,
      onExit: () => void showLevelSelect(world),
      onFinish: (result) => {
        const stars: Stars = computeStars(result.errors);
        recordLevelResult(level.id, stars);
        const coins = featherReward(result.correct, stars);
        addCoins(coins);

        const currentIndex = levels.findIndex((l) => l.id === level.id);
        const nextLevel = levels[currentIndex + 1];

        renderComplete(root, {
          correct: result.correct,
          total: result.total,
          stars,
          coins,
          hasNextLevel: Boolean(nextLevel),
          onRepeat: () => void playLevel(world, levels, level),
          onNextLevel: () => {
            if (nextLevel) void playLevel(world, levels, nextLevel);
          },
          onBackToMap: () => void showWorldMap()
        });
      }
    });
  }

  await showWorldMap();
}
