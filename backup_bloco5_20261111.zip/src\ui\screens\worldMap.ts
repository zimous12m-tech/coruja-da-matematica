import type { World } from '../../content/schema';
import { t } from '../../services/i18n';
import { worldIcon } from '../components/icons';
import { owlSvg } from '../components/owl';

export interface WorldMapDeps {
  worlds: readonly World[];
  save: { coins: number; stars: Record<string, number> };
  onOpenWorld: (worldId: string) => void;
}

export function renderWorldMap(root: HTMLElement, deps: WorldMapDeps): void {
  const cards = deps.worlds
    .map((world) => {
      const levelIds = [1, 2, 3, 4, 5, 6].map((n) => `${world.id}-nivel-${n}`);
      const earned = levelIds.reduce((sum, id) => sum + (deps.save.stars[id] ?? 0), 0);
      return `<li>
        <button class="world" type="button" data-world="${world.id}" style="--world:${world.cor};--world-soft:${world.corSuave}">
          <span class="world__icon">${worldIcon(world.icone, 36)}</span>
          <span class="world__body">
            <span class="world__name">${world.nome['pt-PT']}</span>
            <span class="world__desc">${world.descricao['pt-PT']}</span>
            <span class="world__meta">${t('world.stars', { done: earned, total: 18 })}</span>
          </span>
        </button>
      </li>`;
    })
    .join('');

  root.innerHTML = `
    <main class="screen">
      <header class="topbar">
        <div class="topbar__profile">
          ${owlSvg(48)}
          <span class="chip">${t('menu.coins', { count: deps.save.coins })}</span>
        </div>
      </header>
      <h1>${t('world.title')}</h1>
      <ul class="world-list">${cards}</ul>
    </main>`;

  root.querySelectorAll<HTMLButtonElement>('[data-world]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const id = btn.dataset.world;
      if (id) deps.onOpenWorld(id);
    });
  });
}
